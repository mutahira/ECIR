# DFS²C: An End-to-End Pipeline for Schema-Guided Data Analysis Automation

DFS²C (**D**irectory Reader, **F**ile Selector, **S**ample Generator, **S**chema Generator, and **C**ode Generator) is an end-to-end framework for automating text-centric data analysis using Large Language Models (LLMs).

Unlike conventional LLM-based analytical systems that directly ingest complete datasets into the model context, DFS²C progressively transforms datasets into compact semantic representations before analytical reasoning. This design substantially reduces token consumption, computational cost, and raw data exposure while preserving the structural information required for downstream analysis.

The framework is designed to support heterogeneous datasets, including structured, semi-structured, and unstructured text data, allowing users to perform analytical tasks using natural language without manually exploring complex dataset structures.

---

## Framework Overview

The pipeline consists of five sequential stages:

### 📁 1. Directory Reader

Reads the dataset directory structure and creates a compact hierarchical representation of files and folders without exposing complete dataset contents.

### 📄 2. File Selector

Uses an LLM to identify the files that are most relevant for answering a user's analytical query while determining an appropriate sampling strategy.

### ✂️ 3. Sample Generator

Generates representative samples from the selected files, minimizing unnecessary data exposure while preserving important structural and semantic characteristics.

### 🧩 4. Schema Generator

Transforms the sampled data into a JSON-LD semantic schema describing dataset attributes, relationships, and metadata. This schema serves as the primary reasoning substrate for downstream analysis.

### 💻 5. Code Generator

Combines the generated schema with a user's natural-language query to produce executable analytical code (e.g., Python), enabling tasks such as preprocessing, visualization, statistical analysis, and machine learning.

---

## Framework Architecture

<p align="center">
  <img src="DFS2C_methodology.png" width="900">
</p>

---

## Features

- Supports local datasets
- Supports GitHub repositories as datasets
- LLM-based file selection
- JSON-LD schema generation
- Progressive semantic dataset abstraction
- Automatic analytical code generation

---

## Requirements

### System Requirements

- Python 3.11+
- Poetry (recommended) or pip
- Operating System: Linux, macOS, or Windows

---

## API Keys

DFS²C currently requires an OpenAI API key.

Create one at:

https://platform.openai.com/

---

## Installation

### 1. Clone the repository

```bash
git clone git@gitlab.com:TIBHannover/orkg/tib-aissistant/assistants/dfs2c_data_analysis.git

cd dfs2c_data_analysis
```

---

### 2. Install Python dependencies

Using Poetry

Install Poetry (if you do not already have it):

```bash
curl -sSL https://install.python-poetry.org | python3 -
```

Install project dependencies:

```bash
poetry install
```

---

### 3. Configure environment variables

Create a `.env` file in the project root.

#### Required (Core DFS²C Pipeline)

These variables are required to run the core DFS²C pipeline.

```text
OPENAI_API_KEY=your_openai_api_key
```

You can use `.env.example` as a starting point.

---

## Running DFS²C

Using Poetry

```bash
poetry run uvicorn app.main:app --reload
```

or using pip

```bash
uvicorn app.main:app --reload
```

The backend will be available at:

```
http://localhost:8000
```

---

## Repository Structure

```text
dfs2c_data_analysis/
├── app/                      # Main application code
│   ├── main.py               # Application entry point
│   ├── app_factory.py        # App configuration
│   ├── routers/              # HTTP endpoints
│   ├── services/             # Business logic
│   ├── models/               # Pydantic data models
│   ├── core/                 # Core utilities
│   │   ├── decorators.py     # Logging decorators
│   │   └── streaming/        # Streaming infrastructure
│   ├── templates/            # Jinja2 prompt templates
│   ├── static/               # HTML demo pages
│   └── directory_reader/     # Directory reading utilities
├── tests/                    # Test suite
├── rules/                    # Documentation
├── pyproject.toml            # Project dependencies
└── README.md                 # Project documentation
```

---


## License

This project is released under the MIT License.