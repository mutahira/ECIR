from pydantic import BaseModel, Field, HttpUrl
from typing import Dict, List, Optional, Union


class FileToRead(BaseModel):
    file_path: str = Field(..., description="Path relative to dataset root")

    lines_to_read: int = Field(
        10,
        description="Number of lines to read",
        gt=0,
    )


class SampleGeneratorRequest(BaseModel):
    dataset_path: Union[str, HttpUrl] = Field(
        ..., description="Local dataset root path or GitHub repository URL"
    )

    files: List[FileToRead] = Field(..., description="Files selected by File Selector")


class SampleGeneratorResponse(BaseModel):
    success: bool = Field(..., description="Indicates if the operation was successful")

    files_content: Optional[Dict[str, str]] = Field(
        None, description="file_path -> sampled content"
    )

    error_message: Optional[str] = Field(
        None, description="Error message if operation failed"
    )
