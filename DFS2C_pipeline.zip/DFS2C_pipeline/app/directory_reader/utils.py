def is_github_url(path: str) -> bool:
    return "github.com" in path.lower()