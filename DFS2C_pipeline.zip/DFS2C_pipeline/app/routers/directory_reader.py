import http
import logging

from fastapi import APIRouter, HTTPException

from app.models.directory_reader import (
    ReadDirectoryRequest,
    ReadDirectoryResponse,
)

from app.services.directory_reader import (
    read_directory_with_fuzzy_matching,
)

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/directory",
    tags=["Directory Reader"],
)


@router.post(
    "/reader",
    status_code=http.HTTPStatus.OK,
    response_model=ReadDirectoryResponse,
)
def read_directory(request: ReadDirectoryRequest):

    try:

        structure = read_directory_with_fuzzy_matching(request.path)

        return ReadDirectoryResponse(
            success=True,
            structure=structure,
        )

    except Exception:

        logger.exception("Failed to read directory structure")

        raise HTTPException(
            status_code=http.HTTPStatus.INTERNAL_SERVER_ERROR,
            detail="Failed to read directory structure",
        )