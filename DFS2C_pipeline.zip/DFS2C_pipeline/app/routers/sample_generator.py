import http
import logging

from fastapi import APIRouter, HTTPException

from app.models.sample_generator import (
    SampleGeneratorRequest,
    SampleGeneratorResponse,
)

from app.services.sample_generator import (
    dataset_files_reader,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/sample", tags=["Sample Generator"])


@router.post(
    "/generator",
    status_code=http.HTTPStatus.OK,
    response_model=SampleGeneratorResponse,
)
def load_dataset(request: SampleGeneratorRequest):

    try:

        files_content = dataset_files_reader(
            dataset_path=request.dataset_path,
            files=request.files,
        )

        return SampleGeneratorResponse(
            success=True,
            files_content=files_content,
            error_message=None,
        )

    except Exception:

        logger.exception("Failed to load dataset samples")

        raise HTTPException(
            status_code=http.HTTPStatus.INTERNAL_SERVER_ERROR,
            detail="Failed to load dataset samples",
        )