from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from app.core.decorators import log
from app.models.schema_generator import SchemaRequest
from app.services.schema_generator import SchemaStreamingService

router = APIRouter(prefix="/schema", tags=["Schema Generator"])


@router.post("/generator", response_class=StreamingResponse)
@log(__name__)
def stream_dataset_schema(request: SchemaRequest):
    """
    Streaming endpoint: returns the LLM output as it arrives.
    No parsing or post-processing.
    """
    try:
        service = SchemaStreamingService()
        return service.stream_schema(
            files_content=request.files_content, model=request.model or "gpt-4o"
        )
    except ValueError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Failed to stream schema: {str(e)}"
        )
