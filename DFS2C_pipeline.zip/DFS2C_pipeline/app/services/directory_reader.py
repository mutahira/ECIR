from pathlib import Path
from typing import Union, Dict, Any, Optional
from urllib.parse import urlparse

import requests

from app.directory_reader.utils import is_github_url
from app.directory_reader.fuzzy_grouper import fuzzy_group_files


def normalize_path_input(path: str) -> str:

    path = path.strip()

    if "github.com" in path:

        path = path.replace("\\", "/")

        if path.startswith("https:/") and not path.startswith("https://"):
            path = path.replace("https:/", "https://", 1)

        if path.startswith("http:/") and not path.startswith("http://"):
            path = path.replace("http:/", "http://", 1)

    return path


def read_directory_with_fuzzy_matching(
    path: Union[str, Path],
    include_hidden: bool = False,
    fuzzy_threshold: int = 50,
    max_depth: Optional[int] = None,
) -> Dict[str, Any]:

    if isinstance(path, str):
        path = normalize_path_input(path)

    if isinstance(path, str) and is_github_url(path):
        return read_github_directory(
            path,
            fuzzy_threshold=fuzzy_threshold,
        )

    path = Path(path)

    if not path.exists():
        raise FileNotFoundError(f"Path '{path}' does not exist")

    if path == Path("/"):
        raise PermissionError("Refusing to scan root directory '/'")

    def process_dir(
        p: Path,
        depth: int = 0,
    ):

        if max_depth is not None and depth > max_depth:
            return {
                "name": p.name,
                "type": "directory",
                "files_count": 0,
                "sample_files": [],
                "children": [],
            }

        if not include_hidden and p.name.startswith("."):
            return {}

        try:
            entries = list(p.iterdir())
        except PermissionError:
            return {}

        files = [f for f in entries if f.is_file()]

        if not include_hidden:
            files = [f for f in files if not f.name.startswith(".")]

        node = {
            "name": p.name,
            "type": "directory",
            "files_count": len(files),
            "sample_files": [],
            "children": [],
        }

        if len(files) >= fuzzy_threshold:

            groups = fuzzy_group_files(
                [{"name": str(f.relative_to(path))} for f in files]
            )

            samples = []

            for g in groups:

                if isinstance(g, dict):
                    samples.extend(g.get("sample", []))
                else:
                    samples.append(g["name"])

            node["sample_files"] = samples[:30]

        else:

            node["sample_files"] = [
                str(f.relative_to(path))
                for f in files[:30]
            ]

        for child in entries:

            if child.is_dir():

                child_node = process_dir(
                    child,
                    depth + 1,
                )

                if child_node:
                    node["children"].append(child_node)

        return node

    return process_dir(path)


def read_github_directory(
    github_url: str,
    fuzzy_threshold: int = 50,
):

    parsed = urlparse(github_url)

    parts = parsed.path.strip("/").split("/")

    owner = parts[0]
    repo = parts[1]

    branch = None
    target_path = ""

    if len(parts) >= 4 and parts[2] == "tree":

        branch = parts[3]

        if len(parts) > 4:
            target_path = "/".join(parts[4:])

    if branch is None:

        try:
            repo_info = requests.get(
                f"https://api.github.com/repos/{owner}/{repo}"
            )
            repo_info.raise_for_status()

        except requests.RequestException as e:
            raise RuntimeError(
                f"Failed to retrieve GitHub repository information: {e}"
            ) from e

        branch = repo_info.json()["default_branch"]

    try:
        tree_response = requests.get(
            f"https://api.github.com/repos/"
            f"{owner}/{repo}/git/trees/"
            f"{branch}?recursive=1"
        )
        tree_response.raise_for_status()

    except requests.RequestException as e:
        raise RuntimeError(
            f"Failed to retrieve GitHub directory tree: {e}"
        ) from e

    tree = tree_response.json()["tree"]

    root_name = target_path.split("/")[-1] if target_path else repo

    root = {
        "name": root_name,
        "type": "directory",
        "files_count": 0,
        "sample_files": [],
        "children": {},
    }

    for item in tree:

        if item["type"] != "blob":
            continue

        file_path = item["path"]

        if target_path:

            if not file_path.startswith(target_path):
                continue

            file_path = file_path[len(target_path):].lstrip("/")

        if not file_path:
            continue

        parts = file_path.split("/")

        current = root

        for part in parts[:-1]:

            if part not in current["children"]:

                current["children"][part] = {
                    "name": part,
                    "type": "directory",
                    "files_count": 0,
                    "sample_files": [],
                    "children": {},
                    "_files": [],
                }

            current = current["children"][part]

        current.setdefault("_files", []).append(file_path)

    def finalize(node):

        files = node.pop("_files", [])

        node["files_count"] = len(files)

        if len(files) >= fuzzy_threshold:

            groups = fuzzy_group_files([{"name": f} for f in files])

            samples = []

            for g in groups:

                if isinstance(g, dict):
                    samples.extend(g.get("sample", []))
                else:
                    samples.append(g["name"])

            node["sample_files"] = samples[:30]

        else:

            node["sample_files"] = files[:30]

        node["children"] = [
            finalize(child)
            for child in node["children"].values()
        ]

        return node

    return finalize(root)
