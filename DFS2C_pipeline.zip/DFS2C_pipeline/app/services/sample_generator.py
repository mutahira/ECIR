import os
from io import BytesIO
from urllib.parse import urlparse

import pandas as pd
from app.directory_reader.utils import (
    is_github_url,)
from io import BytesIO
import pandas as pd

import requests

def parse_github_url(repo_url: str):
    """
    Supports:

    https://github.com/user/repo

    https://github.com/user/repo/tree/main/data

    https://github.com/user/repo/tree/master/data/csv
    """

    parsed = urlparse(repo_url)
    parts = parsed.path.strip("/").split("/")

    if len(parts) < 2:
        raise ValueError(f"Invalid GitHub URL: {repo_url}")

    owner = parts[0]
    repo = parts[1]

    branch = None
    base_path = ""

    # Support both /tree/... and /blob/...
    if len(parts) >= 4 and parts[2] in ("tree", "blob"):
        branch = parts[3]

        if len(parts) > 4:
            base_path = "/".join(parts[4:])

    return owner, repo, branch, base_path


def get_default_branch(
    owner: str,
    repo: str,
) -> str:
    try:
        response = requests.get(
            f"https://api.github.com/repos/{owner}/{repo}"
        )
        response.raise_for_status()
    except requests.RequestException as e:
        raise RuntimeError(
            "Failed to retrieve the GitHub repository information."
        ) from e

    return response.json()["default_branch"]


def read_github_file(
    repo_url: str,
    file_path: str,
    num_lines: int,
) -> str:

    owner, repo, branch, base_path = parse_github_url(repo_url)

    if branch is None:
        branch = get_default_branch(owner, repo)

    if base_path:
        file_path = f"{base_path}/{file_path}"

    raw_url = (
        f"https://raw.githubusercontent.com/"
        f"{owner}/{repo}/{branch}/{file_path}"
    )

    try:
        response = requests.get(raw_url, stream=True)
        response.raise_for_status()
    except requests.RequestException as e:
        raise RuntimeError(
            "Failed to retrieve the GitHub file."
        ) from e

    # Excel files are binary, so don't use iter_lines()
    if file_path.lower().endswith(".xlsx"):
        try:
            df = pd.read_excel(
                BytesIO(response.content),
                engine="openpyxl",
            )
        except Exception as e:
            raise RuntimeError(
                "Failed to read the Excel file."
            ) from e

        return df.head(num_lines).to_csv(index=False)

    # Text files
    lines = []

    for i, line in enumerate(response.iter_lines(decode_unicode=True)):
        if i >= num_lines:
            break

        if line is None:
            continue

        lines.append(line)

    return "\n".join(lines)


def read_local_file(
    dataset_path: str,
    file_path: str,
    num_lines: int,
) -> str:

    full_path = os.path.join(
        dataset_path,
        file_path,
    )

    if not os.path.exists(full_path):
        raise FileNotFoundError(full_path)

    with open(
        full_path,
        "r",
        encoding="utf-8",
        errors="ignore",
    ) as f:

        return "".join(f.readlines()[:num_lines])


def dataset_files_reader(
    dataset_path: str,
    files: list,
):

    files_content = {}

    github_mode = is_github_url(str(dataset_path))

    for file_info in files:

        if isinstance(file_info, dict):
            file_path = file_info["file_path"]
            num_lines = file_info["lines_to_read"]
        else:
            file_path = file_info.file_path
            num_lines = file_info.lines_to_read

        if github_mode:

            content = read_github_file(
                repo_url=str(dataset_path),
                file_path=file_path,
                num_lines=num_lines,
            )

        else:

            content = read_local_file(
                dataset_path=str(dataset_path),
                file_path=file_path,
                num_lines=num_lines,
            )

        files_content[file_path] = content

    return files_content
