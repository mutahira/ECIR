import json
import os
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.routers import (
    directory_reader,
    file_selector,
    sample_generator,
    schema_generator,
    code_generator,
)


def get_application() -> FastAPI:
    _app = FastAPI(
        title="DFS2C: Data Analysis backend",
    )

    __configure_routers(_app)
    _configure_cors_policy(_app)
    _configure_static_files(_app)
    _save_openapi_specification(_app)
    return _app


def _configure_cors_policy(app: FastAPI):
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )


def __configure_routers(app: FastAPI):
    # Core DFS²C pipeline
    app.include_router(directory_reader.router)
    app.include_router(file_selector.router)
    app.include_router(sample_generator.router)
    app.include_router(schema_generator.router)
    app.include_router(code_generator.router)


def _configure_static_files(app: FastAPI):
    static_dir = Path(__file__).parent / "static"
    if static_dir.exists():
        app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")


def _save_openapi_specification(app: FastAPI):
    app_dir = os.path.dirname(os.path.realpath(__file__))
    _write_json(app.openapi(), os.path.join(app_dir, "..", "openapi.json"))


def _write_json(data, input_path):
    with open(input_path, "w") as f:
        json.dump(data, f, indent=4)
